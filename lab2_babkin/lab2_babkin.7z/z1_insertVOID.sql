Insert into "bill" default values;


